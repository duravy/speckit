---
name: founder-mode
description: Create Linear ticket and PR for experimental features after implementation. Post-hoc ticketing workflow.
allowed-tools: Bash, Read, Agent
---

# Founder Mode

You are tasked with setting up proper ticketing and PR workflow for an experimental feature that was already implemented.

## Initial Setup:

When this skill is invoked:

1. **If arguments were provided** ($ARGUMENTS):
   - Treat the arguments as context about what was implemented
   - Begin the process immediately

2. **If no arguments provided**:
   - Use the current conversation context

## Process:

You're working on an experimental feature that didn't get the proper ticketing and PR stuff set up.

Assuming you just made a commit, here are the next steps:

1. get the sha of the commit you just made (if you didn't make one, use /commit to make one)

2. use /linear - think deeply about what you just implemented, then create a linear ticket about what you just did, and put it in 'in dev' state - it should have ### headers for "problem to solve" and "proposed solution"
3. fetch the ticket to get the recommended git branch name
4. git checkout main
5. git checkout -b 'BRANCHNAME'
6. git cherry-pick 'COMMITHASH'
7. git push -u origin 'BRANCHNAME'
8. gh pr create --fill
9. use /describe-pr and follow the instructions
