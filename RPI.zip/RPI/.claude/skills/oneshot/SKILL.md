---
name: oneshot
description: Research ticket and launch planning session. Combines ralph-research with a launched planning session.
allowed-tools: Bash, Agent
argument-hint: "[ticket number e.g. ENG-XXXX]"
---

# Oneshot

## Initial Setup:

When this skill is invoked:

1. **If arguments were provided** ($ARGUMENTS):
   - Treat the arguments as the ticket number
   - Begin immediately

2. **If no arguments provided**:
   - Ask for the ticket number

## Process:

1. Use the /ralph-research skill with the given ticket number
2. Launch a new session with `npx humanlayer launch --model opus --dangerously-skip-permissions --dangerously-skip-permissions-timeout 14m --title "plan ENG-XXXX" "/oneshot-plan ENG-XXXX"`
