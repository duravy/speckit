---
name: create-worktree
description: Create worktree and launch implementation session for a plan. Sets up isolated git worktree with proper configuration.
allowed-tools: Bash, Read
argument-hint: "[plan file path]"
---

# Create Worktree

## Initial Setup:

When this skill is invoked:

1. **If arguments were provided** ($ARGUMENTS):
   - Treat the arguments as the plan file path or ticket reference
   - Begin the worktree setup process immediately

2. **If no arguments provided**:
   - Ask the user for the plan file path

## Process:

2. set up worktree for implementation:
2a. read `hack/create_worktree.sh` and create a new worktree with the Linear branch name: `./hack/create_worktree.sh ENG-XXXX BRANCH_NAME`

3. determine required data:

branch name
path to plan file (use relative path only)
launch prompt
command to run

**IMPORTANT PATH USAGE:**
- The thoughts/ directory is synced between the main repo and worktrees
- Always use ONLY the relative path starting with `thoughts/shared/...` without any directory prefix
- Example: `thoughts/shared/plans/fix-mcp-keepalive-proper.md` (not the full absolute path)
- This works because thoughts are synced and accessible from the worktree

3a. confirm with the user by sending a message to the Human

```
based on the input, I plan to create a worktree with the following details:

worktree path: ~/wt/humanlayer/ENG-XXXX
branch name: BRANCH_NAME
path to plan file: $FILEPATH
launch prompt:

    /implement-plan at $FILEPATH and when you are done implementing and all tests pass, use /commit to create a commit, then use /describe-pr to create a PR, then add a comment to the Linear ticket with the PR link

command to run:

    humanlayer launch --model opus -w ~/wt/humanlayer/ENG-XXXX "/implement-plan at $FILEPATH and when you are done implementing and all tests pass, use /commit to create a commit, then use /describe-pr to create a PR, then add a comment to the Linear ticket with the PR link"
```

incorporate any user feedback then:

4. launch implementation session: `humanlayer launch --model opus -w ~/wt/humanlayer/ENG-XXXX "/implement-plan at $FILEPATH and when you are done implementing and all tests pass, use /commit to create a commit, then use /describe-pr to create a PR, then add a comment to the Linear ticket with the PR link"`
