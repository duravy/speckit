---
name: oneshot-plan
description: Execute ralph plan and implementation for a ticket. Chains ralph-plan and ralph-impl skills together.
allowed-tools: Agent
argument-hint: "[ticket number e.g. ENG-XXXX]"
---

# Oneshot Plan

## Initial Setup:

When this skill is invoked:

1. **If arguments were provided** ($ARGUMENTS):
   - Treat the arguments as the ticket number
   - Begin immediately

2. **If no arguments provided**:
   - Ask for the ticket number

## Process:

1. Use the /ralph-plan skill with the given ticket number
2. Use the /ralph-impl skill with the given ticket number
