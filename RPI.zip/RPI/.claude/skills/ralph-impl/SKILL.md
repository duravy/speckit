---
name: ralph-impl
description: Implement highest priority small Linear ticket with worktree setup. Fetches ready-for-dev tickets and launches implementation.
model: sonnet
allowed-tools: Bash, Read, Agent, TodoWrite
argument-hint: "[ticket number e.g. ENG-XXXX]"
---

# Ralph Implementation

## Initial Setup:

When this skill is invoked:

1. **If arguments were provided** ($ARGUMENTS):
   - Treat the arguments as the ticket number
   - Skip to PART I - IF A TICKET IS MENTIONED

2. **If no arguments provided**:
   - Follow PART I - IF NO TICKET IS MENTIONED

## PART I - IF A TICKET IS MENTIONED

0c. use `linear` cli to fetch the selected item into thoughts with the ticket number - ./thoughts/shared/tickets/ENG-xxxx.md
0d. read the ticket and all comments to understand the implementation plan and any concerns

## PART I - IF NO TICKET IS MENTIONED

0.  read .claude/skills/linear/SKILL.md
0a. fetch the top 10 priority items from linear in status "ready for dev" using the MCP tools, noting all items in the `links` section
0b. select the highest priority SMALL or XS issue from the list (if no SMALL or XS issues exist, EXIT IMMEDIATELY and inform the user)
0c. use `linear` cli to fetch the selected item into thoughts with the ticket number - ./thoughts/shared/tickets/ENG-xxxx.md
0d. read the ticket and all comments to understand the implementation plan and any concerns

## PART II - NEXT STEPS

think deeply

1. move the item to "in dev" using the MCP tools
1a. identify the linked implementation plan document from the `links` section
1b. if no plan exists, move the ticket back to "ready for spec" and EXIT with an explanation

think deeply about the implementation

2. set up worktree for implementation:
2a. read `hack/create_worktree.sh` and create a new worktree with the Linear branch name: `./hack/create_worktree.sh ENG-XXXX BRANCH_NAME`
2b. launch implementation session: `humanlayer-nightly launch --model opus --dangerously-skip-permissions --dangerously-skip-permissions-timeout 15m --title "implement ENG-XXXX" -w ~/wt/humanlayer/ENG-XXXX "/implement-plan and when you are done implementing and all tests pass, use /commit to create a commit, then use /describe-pr to create a PR, then add a comment to the Linear ticket with the PR link"`

think deeply, use TodoWrite to track your tasks. When fetching from linear, get the top 10 items by priority but only work on ONE item - specifically the highest priority SMALL or XS sized issue.
